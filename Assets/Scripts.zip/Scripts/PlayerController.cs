using UnityEngine;
using UnityEngine.AI;

public class PlayerController : MonoBehaviour
{
    [Header("Movement Settings")]
    public float moveSpeed = 5f;                // 이동 속도 (더 크게 하면 더 빠르게 이동, 예: 10f)
    public float rotationSpeed = 10f;            // 회전 속도 (더 크게 하면 더 빠르게 회전, 예: 20f)
    
    private NavMeshAgent agent;
    private Animator animator;
    private bool isInitialized = false;
    
    public bool IsInitialized()
    {
        return isInitialized;
    }
    
    void Start()
    {
        InitializeAgent();
    }
    
    public void InitializeAgent()
    {
        // NavMeshAgent 컴포넌트 가져오기 또는 추가
        agent = GetComponent<NavMeshAgent>();
        if (agent == null)
        {
            agent = gameObject.AddComponent<NavMeshAgent>();
        }
        
        // NavMeshAgent 설정
        agent.speed = moveSpeed;
        agent.angularSpeed = rotationSpeed;
        agent.acceleration = 20f;                 // 가속도 (더 크게 하면 더 빠르게 가속, 예: 40f)
        agent.stoppingDistance = 0.3f;
        agent.radius = 0.2f; // 반지름 감소 (더 정확한 경로)
        agent.height = 2f;
        agent.autoBraking = true;
        agent.autoRepath = true; // 자동 경로 재계산
        agent.obstacleAvoidanceType = UnityEngine.AI.ObstacleAvoidanceType.NoObstacleAvoidance; // 장애물 회피 비활성화
        
        // NavMesh 위로 강제 이동
        ForceToNavMesh();
        
        // Animator 가져오기 또는 추가
        animator = GetComponent<Animator>();
        if (animator == null)
        {
            animator = gameObject.AddComponent<Animator>();
        }
        
        isInitialized = true;
    }
    
    void ForceToNavMesh()
    {
        NavMeshHit hit;
        if (NavMesh.SamplePosition(transform.position, out hit, 10f, NavMesh.AllAreas))
        {
            transform.position = hit.position;
            agent.Warp(hit.position);
        }
        else
        {
            // NavMesh를 찾을 수 없으면 기본 위치로 이동
            Vector3 defaultPos = new Vector3(0, 0, 0);
            if (NavMesh.SamplePosition(defaultPos, out hit, 50f, NavMesh.AllAreas))
            {
                transform.position = hit.position;
                agent.Warp(hit.position);
            }
        }
    }
    
    public void MoveToPosition(Vector3 targetPosition)
    {
        Vector3 beforeMove = transform.position;
        
        if (!isInitialized)
        {
            InitializeAgent();
        }
        
        // NavMesh 위에 있는지 다시 확인
        if (!agent.isOnNavMesh)
        {
            ForceToNavMesh();
            Vector3 afterForce = transform.position;
            if (Mathf.Abs(afterForce.y - beforeMove.y) > 0.01f)
            {
                Debug.LogWarning($"[MoveToPosition - ForceToNavMesh] {gameObject.name}: y좌표 {beforeMove.y} → {afterForce.y}, 차이={afterForce.y - beforeMove.y}");
            }
        }
        
        if (agent != null && agent.enabled)
        {
            // 이전 경로 정리
            agent.ResetPath();
            
            // 목표 위치가 NavMesh 위에 있는지 확인 (검색 범위를 넓힘)
            NavMeshHit hit;
            Vector3 beforeSample = targetPosition;
            if (NavMesh.SamplePosition(targetPosition, out hit, 5f, NavMesh.AllAreas))
            {
                Vector3 validTarget = hit.position;
                if (Mathf.Abs(validTarget.y - beforeSample.y) > 0.01f)
                {
                    Debug.LogWarning($"[MoveToPosition - NavMesh 샘플링] {gameObject.name}: 목표 y={beforeSample.y}, 유효 y={validTarget.y}, 차이={validTarget.y - beforeSample.y}");
                }
                agent.SetDestination(validTarget);
            }
            else
            {
                Debug.LogWarning($"{gameObject.name}: 목표 위치 주변에 NavMesh를 찾을 수 없습니다. 원본 위치로 이동 시도: {targetPosition}");
                // NavMesh를 찾을 수 없어도 원본 위치로 이동 시도
                agent.SetDestination(targetPosition);
            }
        }
        else
        {
            Debug.LogError($"{gameObject.name}: NavMeshAgent가 null이거나 비활성화됨");
        }
    }
    
    public bool IsMoving()
    {
        if (agent == null || !agent.enabled)
            return false;
            
        return agent.velocity.magnitude > 0.1f;
    }
    
    public bool HasReachedDestination()
    {
        if (agent == null || !agent.enabled || !agent.isOnNavMesh)
            return true;
            
        // 경로가 없거나 완료되었고, 목적지에 충분히 가까우면 도착한 것으로 간주
        bool hasPath = agent.hasPath;
        bool pathPending = agent.pathPending;
        float remainingDistance = agent.remainingDistance;
        float velocity = agent.velocity.magnitude;
        
        // 속도가 거의 0이고 목적지에 가까우면 도착한 것으로 간주
        bool reached = !pathPending && (!hasPath || (remainingDistance < 0.4f && velocity < 0.05f));
        
        return reached;
    }
    
    void Update()
    {
        // 애니메이션 업데이트
        if (animator != null)
        {
            float speed = agent != null ? agent.velocity.magnitude : 0f;
            bool isMoving = speed > 0.01f;
            
            // Animator 파라미터 설정
            animator.SetFloat("Speed", speed);
            animator.SetBool("IsMoving", isMoving);
        }
    }
}