using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine.InputSystem;

public class YutGameManager : MonoBehaviour
{
    [Header("Game Components")]
    public PlayerController[] players; // 0~3: 바바리안, 4~7: 기사
    public Transform[] boardPositions; // 나무 발판 위치들 (A1~F5)
    public Button throwButton;
    public TextMeshProUGUI resultText;
    public TextMeshProUGUI positionText;
    public YutThrowController yutThrowController; // 물리 윷 던지기 컨트롤러
    
    [Header("Managers")]
    public YutPlatformManager platformManager;
    public YutHorseManager horseManager;
    public YutInputHandler inputHandler;
    public YutMovementManager movementManager;
    
    [Header("Test Buttons (테스트용 - 나중에 삭제 가능)")]
    public Button testDoButton;      // 도 테스트 버튼
    public Button testGaeButton;    // 개 테스트 버튼
    public Button testGeolButton;   // 걸 테스트 버튼
    public Button testYutButton;    // 윷 테스트 버튼
    public Button testMoButton;     // 모 테스트 버튼
    public Button testBackDoButton; // 빽도 테스트 버튼
    
    [Header("Game State")]
    // 턴 인덱스(0~1): 0=바바리안 팀, 1=기사 팀 (기사 → 바바리안 → 기사 → 바바리안 순서)
    public int currentTurnIndex = 0; // 0: 바바리안, 1: 기사
    public int[] playerPositions; // 0~3: 바바리안, 4~7: 기사
    public bool isPlayerMoving = false;
    public bool canThrowAgain = false; // 윷/모로 인한 추가 던지기 가능 여부
    
    [Header("Golden Platform")]
    public Material goldenPlatformMaterial; // Unity Inspector에서 할당할 황금색 머티리얼 (StumpGolden)
    public bool hasExtraThrow = false; // 추가 던질 기회 여부
    
    [Header("Horse Position Offset")]
    public float positionOffsetDistance = 0.5f; // 같은 위치의 말들 사이 간격
    
    [Header("Platform Selection")]
    public Material selectablePlatformMaterial; // 선택 가능한 발판 하이라이트 머티리얼
    public Material selectableHorseMaterial; // 선택 가능한 말 하이라이트 머티리얼
    [System.NonSerialized]
    private List<int> selectablePlatformIndices; // 현재 선택 가능한 발판 인덱스 목록
    [System.NonSerialized]
    private List<int> selectableHorseIndices; // 현재 선택 가능한 말 인덱스 목록
    [System.NonSerialized]
    private bool waitingForPlatformSelection = false; // 발판 선택 대기 중인지
    [System.NonSerialized]
    private bool waitingForHorseSelection = false; // 말 선택 대기 중인지
    [System.NonSerialized]
    private int currentHorseIndexForMove = -1; // 현재 이동할 말 인덱스
    [System.NonSerialized]
    private int currentMoveSteps = 0; // 현재 이동할 칸 수
    [System.NonSerialized]
    private bool isBackDoTurn = false; // 빽도 턴인지 여부
    [System.NonSerialized]
    private YutOutcome savedYutOutcome = YutOutcome.Nak; // 저장된 윷 결과 (윷/모 다음 낙 시 사용)
    [System.NonSerialized]
    private bool turnChangedInMoveToPlatform = false; // MoveToSelectedPlatform에서 턴이 변경되었는지 여부
    [System.NonSerialized]
    private bool hasSavedYutOutcome = false; // 저장된 윷 결과가 있는지
    [System.NonSerialized]
    private List<YutOutcome> pendingMovements; // 대기 중인 이동 목록
    [System.NonSerialized]
    private Vector3[] horseInitialPositions; // 각 말의 초기 시작 위치 (0~3: 바바리안, 4~7: 기사) - 실제 transform.position 좌표
    
    // 윷놀이 보드 경로 (29개)
    private string[] positionNames = {
        "A1", "A2", "A3", "A4", "A5",
        "B1", "B2", "B3", "B4", "B5", 
        "C1", "C2", "C3", "C4", "C5",
        "D1", "D2", "D3", "D4", "D5",
        "E1", "E2", "EF3", "E4", "E5",
        "F1", "F2", "F4", "F5"
    };
    
    private string[] playerNames = {"바바리안", "기사"};
    
    void Start()
    {
        // 매니저 자동 초기화 (Inspector에서 할당하지 않았을 경우)
        if (platformManager == null)
        {
            platformManager = GetComponent<YutPlatformManager>();
            if (platformManager == null)
            {
                platformManager = gameObject.AddComponent<YutPlatformManager>();
            }
            // platformManager의 필수 데이터 할당
            platformManager.boardPositions = boardPositions;
            platformManager.goldenPlatformMaterial = goldenPlatformMaterial;
            platformManager.selectablePlatformMaterial = selectablePlatformMaterial;
        }
        
        if (horseManager == null)
        {
            horseManager = GetComponent<YutHorseManager>();
            if (horseManager == null)
            {
                horseManager = gameObject.AddComponent<YutHorseManager>();
            }
            // horseManager의 필수 데이터 할당
            horseManager.players = players;
            horseManager.boardPositions = boardPositions;
            horseManager.selectableHorseMaterial = selectableHorseMaterial;
        }
        
        if (inputHandler == null)
        {
            inputHandler = GetComponent<YutInputHandler>();
            if (inputHandler == null)
            {
                inputHandler = gameObject.AddComponent<YutInputHandler>();
            }
            // inputHandler 초기화
            inputHandler.Initialize(this, players, boardPositions, positionNames);
        }
        
        if (movementManager == null)
        {
            movementManager = GetComponent<YutMovementManager>();
            if (movementManager == null)
            {
                movementManager = gameObject.AddComponent<YutMovementManager>();
            }
            // movementManager 초기화
            movementManager.Initialize(this);
        }
        
        // playerPositions 배열 강제 초기화
        // -1: 대기공간, 0 이상: 발판 위치 (0=A1, 1=A2, ...)
        if (playerPositions == null || playerPositions.Length != 8)
        {
            playerPositions = new int[8] {-1, -1, -1, -1, -1, -1, -1, -1}; // 모든 말이 대기공간에 있음
        }
        
        // 각 말의 초기 시작 위치 저장 (실제 transform.position 좌표)
        if (horseInitialPositions == null || horseInitialPositions.Length != 8)
        {
            horseInitialPositions = new Vector3[8];
        }
        
        // 각 말의 초기 위치 좌표 설정 (바바리안 1~4, 기사 1~4 순서)
        horseInitialPositions[0] = new Vector3(97.5f, 1.5f, 32f);  // 바바리안1
        horseInitialPositions[1] = new Vector3(105f, 1.5f, 32f);  // 바바리안2
        horseInitialPositions[2] = new Vector3(97.5f, 1.5f, 28f); // 바바리안3
        horseInitialPositions[3] = new Vector3(105f, 1.5f, 28f);  // 바바리안4
        horseInitialPositions[4] = new Vector3(90f, 1.5f, 32f);   // 기사1
        horseInitialPositions[5] = new Vector3(82.5f, 1.5f, 32f); // 기사2
        horseInitialPositions[6] = new Vector3(90f, 1.5f, 28f);   // 기사3
        horseInitialPositions[7] = new Vector3(82.5f, 1.5f, 28f); // 기사4
        
        
        // 각 말의 transform.position을 초기 위치로 설정
        for (int i = 0; i < players.Length; i++)
        {
            if (players[i] != null)
            {
                players[i].transform.position = horseInitialPositions[i];
            }
        }
        
        // pendingMovements 초기화
        if (pendingMovements == null)
        {
            pendingMovements = new List<YutOutcome>();
        }
        
        // selectablePlatformIndices 초기화
        if (selectablePlatformIndices == null)
        {
            selectablePlatformIndices = new List<int>();
        }
        
        // selectableHorseIndices 초기화
        if (selectableHorseIndices == null)
        {
            selectableHorseIndices = new List<int>();
        }
        
        if (throwButton != null)
        {
            throwButton.onClick.AddListener(ThrowYut);
        }
        else
        {
            Debug.LogError("Throw 버튼이 연결되지 않았습니다!");
        }
        
        // 테스트 버튼 리스너 설정
        if (testDoButton != null)
        {
            testDoButton.onClick.AddListener(() => TestThrowYut(YutOutcome.Do));
        }
        if (testGaeButton != null)
        {
            testGaeButton.onClick.AddListener(() => TestThrowYut(YutOutcome.Gae));
        }
        if (testGeolButton != null)
        {
            testGeolButton.onClick.AddListener(() => TestThrowYut(YutOutcome.Geol));
        }
        if (testYutButton != null)
        {
            testYutButton.onClick.AddListener(() => TestThrowYut(YutOutcome.Yut));
        }
        if (testMoButton != null)
        {
            testMoButton.onClick.AddListener(() => TestThrowYut(YutOutcome.Mo));
        }
        if (testBackDoButton != null)
        {
            testBackDoButton.onClick.AddListener(() => TestThrowYut(YutOutcome.Do, true)); // 빽도는 Do로 전달하되 isBackDo=true
        }
        
        // horseManager 초기화
        horseManager.Initialize(playerPositions, horseInitialPositions);
        
        // 발판 렌더러 초기화 (platformManager 사용)
        platformManager.InitializePlatformRenderers();
        
        // 랜덤 황금 발판 선택 (platformManager 사용)
        platformManager.SelectRandomGoldenPlatform();
        
        UpdateUI();
    }
    
    public void ThrowYut()
    {
        string currentPlayer = currentTurnIndex == 0 ? "바바리안" : "기사";
        Debug.Log($"[턴 시작] {currentPlayer}의 턴 - ThrowYut() 호출됨 (currentTurnIndex: {currentTurnIndex}, isPlayerMoving: {isPlayerMoving})");
        
        if (isPlayerMoving)
        {
            Debug.LogWarning($"[턴 시작 실패] 플레이어가 이동 중입니다. (isPlayerMoving: {isPlayerMoving})");
            return;
        }
        
        StartCoroutine(ThrowAndMoveSequence());
    }
    
    // 테스트용 메서드: 특정 윷 결과를 직접 처리
    public void TestThrowYut(YutOutcome outcome, bool isBackDo = false)
    {
        if (isPlayerMoving) return;
        
        // 테스트 모드로 ThrowAndMoveSequence 호출
        StartCoroutine(ThrowAndMoveSequence(outcome, isBackDo));
    }
    
    IEnumerator ThrowAndMoveSequence(YutOutcome? testOutcome = null, bool testBackDo = false)
    {
        // 턴 변경 플래그 초기화 (새로운 턴 시작 시)
        turnChangedInMoveToPlatform = false;
        
        int currentPlayerIndex = GetCurrentPlayerIndex();
        string currentPlayerName = playerNames[currentPlayerIndex];
        
        if (throwButton != null) throwButton.interactable = false;
        
        // 테스트 버튼 비활성화
        if (testDoButton != null) testDoButton.interactable = false;
        if (testGaeButton != null) testGaeButton.interactable = false;
        if (testGeolButton != null) testGeolButton.interactable = false;
        if (testYutButton != null) testYutButton.interactable = false;
        if (testMoButton != null) testMoButton.interactable = false;
        if (testBackDoButton != null) testBackDoButton.interactable = false;
        
        YutOutcome outcome;
        
        // 테스트 모드인지 확인
        if (testOutcome.HasValue)
        {
            // 테스트 모드: 물리 던지기 스킵하고 결과 직접 사용
            outcome = testOutcome.Value;
            if (testBackDo)
            {
                // 빽도는 Do로 처리하되 나중에 빽도 판정 시 true로 처리
                outcome = YutOutcome.Do;
            }
        }
        else
        {
            // 일반 모드: 물리 윷 던지기
            if (yutThrowController == null)
            {
                Debug.LogError("YutThrowController가 연결되지 않았습니다!");
                if (throwButton != null) throwButton.interactable = true;
                EnableTestButtons();
                yield break;
            }
            
            // 1단계: 윷 던지기 및 멈출 때까지 대기
            yield return StartCoroutine(yutThrowController.ThrowAndWait());
            outcome = yutThrowController.LastOutcome;
        }
        
        // 윷이 완전히 멈춘 후 추가 대기 (시각적 확인) - 테스트 모드가 아닐 때만
        if (!testOutcome.HasValue)
        {
            yield return new WaitForSeconds(0.5f);
        }
        
        // 황금 발판으로 인한 추가 던질 기회 확인 (낙 이전에 체크)
        if (hasExtraThrow)
        {
            hasExtraThrow = false;
            canThrowAgain = true;
            if (resultText != null)
            {
                resultText.text = "황금 발판 효과! 추가 던질 기회 획득!";
            }
            
            if (throwButton != null) throwButton.interactable = true;
            EnableTestButtons();
            yield break;
        }
        
        // 결과 텍스트
        if (resultText != null)
        {
            string outcomeText = OutcomeToKorean(outcome);
            if (testBackDo)
            {
                outcomeText = "빽도";
            }
            string prefix = testOutcome.HasValue ? "[테스트] " : "";
            resultText.text = outcome == YutOutcome.Nak
                ? $"{prefix}{currentPlayerName} 낙! (이동 없음)"
                : $"{prefix}{currentPlayerName}의 윷 결과: {outcomeText}";
        }
        
        // 낙: 저장된 윷/모가 있으면 그것을 사용, 없으면 턴 종료
        bool usedSavedOutcome = false; // 저장된 결과를 사용했는지 여부
        if (outcome == YutOutcome.Nak)
        {
            // 저장된 윷/모가 있으면 그것을 사용
            if (hasSavedYutOutcome)
            {
                outcome = savedYutOutcome;
                hasSavedYutOutcome = false;
                usedSavedOutcome = true; // 저장된 결과를 사용했음을 표시
                
                if (resultText != null)
                {
                    string outcomeText = OutcomeToKorean(outcome);
                    resultText.text = $"낙이 나왔지만 이전 {outcomeText}를 사용합니다!";
                }
                
                // 저장된 윷/모로 이동 처리하도록 계속 진행
            }
            else
            {
                // 저장된 윷/모가 없으면 턴 종료
                if (yutThrowController != null)
                {
                    yield return StartCoroutine(yutThrowController.ResetYutToStartPositionCoroutine());
                    yield return new WaitForSeconds(0.3f);
                }
                
                canThrowAgain = false;
                int oldTurnIndex = currentTurnIndex;
                currentTurnIndex = (currentTurnIndex + 1) % 2; // 팀 단위 턴 변경
                string oldPlayer = oldTurnIndex == 0 ? "바바리안" : "기사";
                string newPlayer = currentTurnIndex == 0 ? "바바리안" : "기사";
                Debug.Log($"[턴 변경 #1 - 낙 처리] {oldPlayer} → {newPlayer} (인덱스: {oldTurnIndex} → {currentTurnIndex})");
                UpdateUI();
                if (throwButton != null) throwButton.interactable = true;
                EnableTestButtons();
                yield break;
            }
        }
        
        int yutResult = (int)outcome; // 1~5
        int moveSteps = GetMoveSteps(yutResult);
        
        // 윷(4)/모(5): 이동 없이 한 번 더 던지기 (턴 유지), 결과 저장
        // 단, 저장된 결과를 사용한 경우에는 다시 저장하지 않고 바로 이동 처리
        if (yutResult == 4 || yutResult == 5)
        {
            // 저장된 결과를 사용한 경우 (낙 후 저장된 윷/모 사용)에는 바로 이동 처리
            if (usedSavedOutcome)
            {
                // 저장된 윷/모를 사용한 경우이므로 바로 이동 처리로 진행
                // (아래 도/개/걸 처리나 빽도 처리로 진행)
            }
            else if (hasSavedYutOutcome)
            {
                // 저장된 윷/모가 있고, 다시 윷/모가 나온 경우: 둘 다 저장하고 한 번 더 던지기
                // (다음에 도/개/걸/빽도/낙이 나오면 모두 함께 사용)
                // pendingMovements에 추가하지 않고, 계속 저장 상태 유지
                // savedYutOutcome은 이미 저장되어 있으므로, 새로 나온 outcome을 추가로 저장할 필요 없음
                // 대신 pendingMovements에 둘 다 추가하여 추적
                pendingMovements.Add(savedYutOutcome);
                pendingMovements.Add(outcome);
                // hasSavedYutOutcome은 false로 설정하지 않고, 새로운 outcome을 savedYutOutcome에 저장
                // 하지만 이렇게 하면 복잡해지므로, pendingMovements에만 추가하고 hasSavedYutOutcome은 false로 설정
                // 대신 다음 던지기에서 도/개/걸/빽도/낙이 나오면 pendingMovements에 추가
                hasSavedYutOutcome = false;
                
                Debug.Log($"저장된 윷/모와 새로 나온 윷/모를 pendingMovements에 추가: {OutcomeToKorean(savedYutOutcome)} + {OutcomeToKorean(outcome)}");
                
                // 윷을 초기 위치로 리셋 (다시 던지기 위해)
                if (yutThrowController != null)
                {
                    yield return StartCoroutine(yutThrowController.ResetYutToStartPositionCoroutine());
                    yield return new WaitForSeconds(0.3f);
                }
                
                canThrowAgain = true;
                UpdateUI();
                if (throwButton != null) throwButton.interactable = true;
                EnableTestButtons();
                yield break;
            }
            else
            {
                // 새로운 윷/모가 나온 경우: 결과 저장하고 한 번 더 던지기
                savedYutOutcome = outcome;
                hasSavedYutOutcome = true;
                
                // 윷을 초기 위치로 리셋 (다시 던지기 위해)
                if (yutThrowController != null)
                {
                    yield return StartCoroutine(yutThrowController.ResetYutToStartPositionCoroutine());
                    yield return new WaitForSeconds(0.3f); // 리셋 애니메이션 대기
                }
                
                canThrowAgain = true;
                UpdateUI();
                if (throwButton != null) throwButton.interactable = true;
                EnableTestButtons();
                yield break;
            }
        }
        
        // 빽도 판정 (여기서 한 번만 선언)
        // 테스트 모드에서 testBackDo가 true면 빽도로 처리
        bool isBackDo = testBackDo || IsBackDo(outcome);
        
        // 저장된 윷/모가 있고, 도/개/걸/빽도가 나왔을 때: 둘 다 이동 가능하게 (순서 자유)
        // 또는 pendingMovements에 이미 윷/모가 있고, 도/개/걸/빽도가 나왔을 때도 추가
        if (hasSavedYutOutcome)
        {
            // 저장된 윷/모와 새로 나온 결과를 대기 목록에 추가
            pendingMovements.Add(savedYutOutcome);
            pendingMovements.Add(outcome);
            hasSavedYutOutcome = false;
            
            if (resultText != null && pendingMovements.Count >= 2)
            {
                string savedText = OutcomeToKorean(pendingMovements[0]);
                string newText = OutcomeToKorean(pendingMovements[1]);
                resultText.text = $"{savedText}와 {newText} 둘 다 이동할 수 있습니다. 이동할 말을 선택하세요";
            }
            else if (resultText != null)
            {
                resultText.text = $"{OutcomeToKorean(pendingMovements[pendingMovements.Count - 1])} 이동할 수 있습니다. 이동할 말을 선택하세요";
            }
            
            // 대기 중인 이동이 모두 처리될 때까지 반복
            turnChangedInMoveToPlatform = false; // 플래그 초기화
            while (pendingMovements.Count > 0)
            {
                // 상태 변수 리셋 (각 이동마다 초기화)
                waitingForHorseSelection = false;
                waitingForPlatformSelection = false;
                currentHorseIndexForMove = -1;
                isBackDoTurn = false;
                
                List<int> horsesToSelect = GetAvailableHorsesForCurrentPlayer();
                if (horsesToSelect.Count > 0)
                {
                    ShowSelectableHorses(horsesToSelect);
                    waitingForHorseSelection = true;
                    
                    // 말 선택 대기
                    while (waitingForHorseSelection)
                    {
                        yield return null;
                    }
                    
                    // 빽도인 경우 특별 처리
                    if (isBackDoTurn)
                    {
                        YutOutcome backDoMovement = YutOutcome.Nak;
                        foreach (YutOutcome movement in pendingMovements)
                        {
                            if (IsBackDo(movement))
                            {
                                backDoMovement = movement;
                                break;
                            }
                        }
                        
                        if (backDoMovement != YutOutcome.Nak)
                        {
                            while (isPlayerMoving)
                            {
                                yield return null;
                            }
                            pendingMovements.Remove(backDoMovement);
                        }
                        isBackDoTurn = false;
                        continue;
                    }
                    
                    // 발판 선택 대기
                    while (waitingForPlatformSelection)
                    {
                        yield return null;
                    }
                    
                    // 이동 완료 대기
                    while (isPlayerMoving)
                    {
                        yield return null;
                    }
                }
                else
                {
                    pendingMovements.Clear();
                }
            }
            
            // 모든 이동 완료 후 턴 종료
            // MoveToSelectedPlatform에서 이미 턴을 변경했다면 여기서는 변경하지 않음
            if (turnChangedInMoveToPlatform)
            {
                isPlayerMoving = false;
                if (throwButton != null) throwButton.interactable = true;
                EnableTestButtons();
                yield break;
            }
            
            canThrowAgain = false;
            
            if (!testOutcome.HasValue && yutThrowController != null)
            {
                yield return StartCoroutine(yutThrowController.ResetYutToStartPositionCoroutine());
                yield return new WaitForSeconds(0.3f);
            }
            
            // 턴 변경
            int oldTurnIndex3 = currentTurnIndex;
            currentTurnIndex = (currentTurnIndex + 1) % 2;
            string oldPlayer3 = oldTurnIndex3 == 0 ? "바바리안" : "기사";
            string newPlayer3 = currentTurnIndex == 0 ? "바바리안" : "기사";
            UpdateUI();
            isPlayerMoving = false;
            
            if (throwButton != null) throwButton.interactable = true;
            EnableTestButtons();
            yield break;
        }
        else if (pendingMovements.Count > 0 && ((yutResult >= 1 && yutResult <= 3) || isBackDo))
        {
            // pendingMovements에 이미 윷/모가 있고, 도/개/걸/빽도가 나온 경우: 추가
            pendingMovements.Add(outcome);
            
            if (resultText != null && pendingMovements.Count >= 2)
            {
                string savedText = OutcomeToKorean(pendingMovements[0]);
                string newText = OutcomeToKorean(pendingMovements[1]);
                resultText.text = $"{savedText}와 {newText} 둘 다 이동할 수 있습니다. 이동할 말을 선택하세요";
            }
            else if (resultText != null)
            {
                resultText.text = $"{OutcomeToKorean(pendingMovements[pendingMovements.Count - 1])} 이동할 수 있습니다. 이동할 말을 선택하세요";
            }
            
            // 대기 중인 이동이 모두 처리될 때까지 반복
            turnChangedInMoveToPlatform = false; // 플래그 초기화
            while (pendingMovements.Count > 0)
            {
                // 상태 변수 리셋 (각 이동마다 초기화)
                waitingForHorseSelection = false;
                waitingForPlatformSelection = false;
                currentHorseIndexForMove = -1;
                isBackDoTurn = false;
                
                List<int> horsesToSelect = GetAvailableHorsesForCurrentPlayer();
                if (horsesToSelect.Count > 0)
                {
                    ShowSelectableHorses(horsesToSelect);
                    waitingForHorseSelection = true;
                    
                    // 말 선택 대기
                    while (waitingForHorseSelection)
                    {
                        yield return null;
                    }
                    
                    // 빽도인 경우 특별 처리
                    if (isBackDoTurn)
                    {
                        YutOutcome backDoMovement = YutOutcome.Nak;
                        foreach (YutOutcome movement in pendingMovements)
                        {
                            if (IsBackDo(movement))
                            {
                                backDoMovement = movement;
                                break;
                            }
                        }
                        
                        if (backDoMovement != YutOutcome.Nak)
                        {
                            while (isPlayerMoving)
                            {
                                yield return null;
                            }
                            pendingMovements.Remove(backDoMovement);
                        }
                        isBackDoTurn = false;
                        continue;
                    }
                    
                    // 발판 선택 대기
                    while (waitingForPlatformSelection)
                    {
                        yield return null;
                    }
                    
                    // 이동 완료 대기
                    while (isPlayerMoving)
                    {
                        yield return null;
                    }
                    
                }
                else
                {
                    pendingMovements.Clear();
                }
            }
            
            // 모든 이동 완료 후 턴 종료
            // MoveToSelectedPlatform에서 이미 턴을 변경했다면 여기서는 변경하지 않음
            if (turnChangedInMoveToPlatform)
            {
                isPlayerMoving = false;
                if (throwButton != null) throwButton.interactable = true;
                EnableTestButtons();
                yield break;
            }
            
            canThrowAgain = false;
            
            if (!testOutcome.HasValue && yutThrowController != null)
            {
                yield return StartCoroutine(yutThrowController.ResetYutToStartPositionCoroutine());
                yield return new WaitForSeconds(0.3f);
            }
            
            // 턴 변경
            int oldTurnIndex2 = currentTurnIndex;
            currentTurnIndex = (currentTurnIndex + 1) % 2;
            string oldPlayer2 = oldTurnIndex2 == 0 ? "바바리안" : "기사";
            string newPlayer2 = currentTurnIndex == 0 ? "바바리안" : "기사";
            Debug.Log($"[턴 변경 #2 - 모든 이동 완료] {oldPlayer2} → {newPlayer2} (인덱스: {oldTurnIndex2} → {currentTurnIndex}, pendingMovements: {pendingMovements.Count}개)");
            UpdateUI();
            isPlayerMoving = false;
            
            if (throwButton != null) throwButton.interactable = true;
            EnableTestButtons();
            yield break;
        }
        else if (pendingMovements.Count == 0 && ((yutResult >= 1 && yutResult <= 3) || isBackDo))
        {
            // pendingMovements가 비어있고 도/개/걸/빽도가 나온 경우: pendingMovements에 추가하여 처리
            pendingMovements.Add(outcome);
            
            // 대기 중인 이동이 모두 처리될 때까지 반복
            turnChangedInMoveToPlatform = false; // 플래그 초기화
            while (pendingMovements.Count > 0)
            {
                List<int> horsesToSelect = GetAvailableHorsesForCurrentPlayer();
                if (horsesToSelect.Count > 0)
                {
                    ShowSelectableHorses(horsesToSelect);
                    waitingForHorseSelection = true;
                    
                    // 말 선택 대기
                    while (waitingForHorseSelection)
                    {
                        yield return null;
                    }
                    
                    // 빽도인 경우 특별 처리
                    // 플레이어가 빽도를 선택했는지 확인 (isBackDoTurn이 true면 빽도 선택)
                    if (isBackDoTurn)
                    {
                        // 빽도 처리 (플레이어가 빽도를 선택함)
                        // 빽도 이동을 pendingMovements에서 찾아서 제거
                        YutOutcome backDoMovement = YutOutcome.Nak;
                        foreach (YutOutcome movement in pendingMovements)
                        {
                            if (IsBackDo(movement))
                            {
                                backDoMovement = movement;
                                break;
                            }
                        }
                        
                        if (backDoMovement != YutOutcome.Nak)
                        {
                            // 빽도 이동 처리
                            while (isPlayerMoving)
                            {
                                yield return null;
                            }
                            // 빽도 이동 완료 후 pendingMovements에서 제거
                            pendingMovements.Remove(backDoMovement);
                        }
                        isBackDoTurn = false;
                        continue;
                    }
                    
                    // 발판 선택 대기
                    while (waitingForPlatformSelection)
                    {
                        yield return null;
                    }
                    
                    // 이동 완료 대기
                    while (isPlayerMoving)
                    {
                        yield return null;
                    }
                    
                    // 다음 이동을 위해 상태 변수 리셋
                    waitingForHorseSelection = false;
                    waitingForPlatformSelection = false;
                    currentHorseIndexForMove = -1;
                    isBackDoTurn = false;
                }
                else
                {
                    // 이동 가능한 말이 없으면 대기 목록 모두 제거
                    pendingMovements.Clear();
                }
            }
            
            // 모든 이동 완료 후 턴 종료
            // MoveToSelectedPlatform에서 이미 턴을 변경했다면 여기서는 변경하지 않음
            if (turnChangedInMoveToPlatform)
            {
                Debug.Log($"[턴 변경 스킵] MoveToSelectedPlatform에서 이미 턴이 변경되었으므로 스킵합니다. (turnChangedInMoveToPlatform: {turnChangedInMoveToPlatform}, currentTurnIndex: {currentTurnIndex})");
                isPlayerMoving = false;
                if (throwButton != null) throwButton.interactable = true;
                EnableTestButtons();
                yield break;
            }
            
            // MoveToSelectedPlatform에서 턴을 변경하지 않았으면 여기서도 변경하지 않음
            // 턴 변경은 MoveToSelectedPlatform에서 처리됨
            isPlayerMoving = false;
            if (throwButton != null) throwButton.interactable = true;
            EnableTestButtons();
            yield break;
        }

        // 2단계: 이동 가능한 발판 표시 및 플레이어 선택 대기
        // 빽도 처리: 빽도면 뒤로 한 칸 이동 (말 선택 필요)
        if (isBackDo)
        {
            isBackDoTurn = true;
            
            // 현재 턴의 플레이어(바바리안 또는 기사)의 모든 말 중에서 선택 가능한 말 찾기
            List<int> backDoAvailableHorses = GetAvailableHorsesForCurrentPlayer();
            
            // 뒤로 갈 수 있는 말만 필터링 (위치가 0보다 큰 말)
            List<int> horsesCanMoveBack = new List<int>();
            foreach (int horseIndex in backDoAvailableHorses)
            {
                if (playerPositions[horseIndex] > 0)
                {
                    horsesCanMoveBack.Add(horseIndex);
                }
            }
            
            if (horsesCanMoveBack.Count > 0)
            {
                // 뒤로 갈 수 있는 말 선택
                ShowSelectableHorses(horsesCanMoveBack);
                waitingForHorseSelection = true;
                
                // 말 선택 대기
                while (waitingForHorseSelection)
                {
                    yield return null;
                }
                
                // 선택된 말 뒤로 이동
                int selectedHorseIndex = currentHorseIndexForMove;
                currentHorseIndexForMove = -1;
                isBackDoTurn = false;
                
                if (selectedHorseIndex >= 0 && selectedHorseIndex < players.Length)
                {
                    if (movementManager != null)
                    {
                        yield return StartCoroutine(movementManager.MoveHorseBackward(selectedHorseIndex, 1));
                    }
                    else
                    {
                        yield return StartCoroutine(MoveHorseBackwardInternal(selectedHorseIndex, 1));
                    }
                }
            }
            else
            {
                // 뒤로 갈 수 있는 말이 없으면
                isBackDoTurn = false;
                if (resultText != null)
                {
                    resultText.text = "뒤로 갈 수 있는 말이 없습니다.";
                }
            }
            
            // 빽도 처리 완료 후 턴 종료
            if (yutThrowController != null)
            {
                yield return StartCoroutine(yutThrowController.ResetYutToStartPositionCoroutine());
                yield return new WaitForSeconds(0.3f);
            }
            
            canThrowAgain = false;
            int oldTurnIndex4 = currentTurnIndex;
            currentTurnIndex = (currentTurnIndex + 1) % 2; // 팀 단위 턴 변경
            string oldPlayer4 = oldTurnIndex4 == 0 ? "바바리안" : "기사";
            string newPlayer4 = currentTurnIndex == 0 ? "바바리안" : "기사";
            Debug.Log($"[턴 변경 #4 - 빽도 처리 완료] {oldPlayer4} → {newPlayer4} (인덱스: {oldTurnIndex4} → {currentTurnIndex})");
            UpdateUI();
            isPlayerMoving = false;
            if (throwButton != null) throwButton.interactable = true;
            EnableTestButtons();
            yield break;
        }
        
        // 도/개/걸: 먼저 말 선택, 그 다음 발판 선택
        currentMoveSteps = moveSteps;
        
        // 현재 턴의 플레이어(바바리안 또는 기사)의 모든 말 중에서 선택 가능한 말 찾기
        List<int> availableHorses = GetAvailableHorsesForCurrentPlayer();
        
        if (availableHorses.Count == 0)
        {
            Debug.LogWarning("이동 가능한 말이 없습니다.");
            if (resultText != null)
            {
                resultText.text = "이동 가능한 말이 없습니다.";
            }
            
            // 윷을 초기 위치로 리셋
            if (yutThrowController != null)
            {
                yield return StartCoroutine(yutThrowController.ResetYutToStartPositionCoroutine());
                yield return new WaitForSeconds(0.3f);
            }
            
            canThrowAgain = false;
            int oldTurnIndex5 = currentTurnIndex;
            currentTurnIndex = (currentTurnIndex + 1) % 2; // 팀 단위 턴 변경
            string oldPlayer5 = oldTurnIndex5 == 0 ? "바바리안" : "기사";
            string newPlayer5 = currentTurnIndex == 0 ? "바바리안" : "기사";
            Debug.Log($"[턴 변경 #5 - 이동 가능한 말 없음] {oldPlayer5} → {newPlayer5} (인덱스: {oldTurnIndex5} → {currentTurnIndex})");
            UpdateUI();
            isPlayerMoving = false;
            if (throwButton != null) throwButton.interactable = true;
            EnableTestButtons();
            yield break;
        }
        
        // 말 선택 모드로 전환
        ShowSelectableHorses(availableHorses);
        waitingForHorseSelection = true;
        
        if (resultText != null)
        {
            string playerName = playerNames[currentPlayerIndex];
            resultText.text = $"{playerName}의 윷 결과: {OutcomeToKorean(outcome)} - 이동할 말을 선택하세요";
        }
        
        // 말 선택 대기
        while (waitingForHorseSelection)
        {
            yield return null;
        }
        
        // 발판 선택 대기
        while (waitingForPlatformSelection)
        {
            yield return null;
        }
        
        // 이동 완료 대기
        while (isPlayerMoving)
        {
            yield return null;
        }
        
        // MoveToSelectedPlatform에서 턴 변경을 처리하므로 여기서는 처리하지 않음
        // pendingMovements가 비어있으면 MoveToSelectedPlatform에서 턴을 변경함
        // pendingMovements가 남아있으면 while 루프에서 계속 처리됨
        
        // 여기서는 단순히 함수 종료 (턴 변경은 MoveToSelectedPlatform에서 처리)
        yield break;
    }
    
    int GetMoveSteps(int yutResult)
    {
        return YutGameUtils.GetMoveSteps(yutResult);
    }
    
    // 현재 턴의 플레이어(0: 바바리안, 1: 기사)
    int GetCurrentPlayerIndex()
    {
        return currentTurnIndex; // 0: 바바리안, 1: 기사
    }
    
    // 테스트 버튼 활성화 헬퍼 함수
    void EnableTestButtons()
    {
        if (testDoButton != null) testDoButton.interactable = true;
        if (testGaeButton != null) testGaeButton.interactable = true;
        if (testGeolButton != null) testGeolButton.interactable = true;
        if (testYutButton != null) testYutButton.interactable = true;
        if (testMoButton != null) testMoButton.interactable = true;
        if (testBackDoButton != null) testBackDoButton.interactable = true;
    }
    
    // Internal 메서드로 변경 (movementManager에서 호출)
    public IEnumerator MoveHorseInternal(int horseIndex, int steps)
    {
        // 인덱스 범위 확인
        if (horseIndex < 0 || horseIndex >= players.Length)
        {
            Debug.LogError($"잘못된 말 인덱스: {horseIndex}, players.Length: {players.Length}");
            yield break;
        }
        
        if (horseIndex >= playerPositions.Length)
        {
            Debug.LogError($"잘못된 말 인덱스: {horseIndex}, playerPositions.Length: {playerPositions.Length}");
            yield break;
        }
        
        isPlayerMoving = true;
        
        // 이동 전에 말이 숨겨져 있으면 일단 보이게 함
        if (players[horseIndex] != null && !players[horseIndex].gameObject.activeSelf)
        {
            players[horseIndex].gameObject.SetActive(true);
        }
        
        // 이동할 말 목록 (업힌 말들)
        // 시작 위치에 같은 팀 말이 있고, 이미 업힌 상태(x2 UI가 있음)인지 확인
        List<int> horsesToMoveTogether = new List<int>();
        int startPosition = playerPositions[horseIndex];
        bool isBarbarian = horseIndex < 4;
        
        // 대기공간(-1)에서 시작하는 경우, 대기공간의 다른 말들을 업지 않음
        if (startPosition != -1)
        {
            // 시작 위치의 같은 팀 말들 찾기 (대기공간 제외)
            List<int> sameTeamHorsesAtStart = new List<int>();
            for (int j = 0; j < playerPositions.Length; j++)
            {
                if (j != horseIndex && playerPositions[j] == startPosition && playerPositions[j] != -1)
                {
                    bool jIsBarbarian = j < 4;
                    if (jIsBarbarian == isBarbarian)
                    {
                        sameTeamHorsesAtStart.Add(j);
                    }
                }
            }
            
            // 같은 위치에 같은 팀 말이 2개 이상 있으면 업힌 상태
            // 첫 번째 말(인덱스가 작은 말)에 x2 UI가 있을 수 있음
            if (sameTeamHorsesAtStart.Count >= 1)
            {
                // 같은 위치의 같은 팀 말들 중 첫 번째 말 찾기
                List<int> allSameTeamHorses = new List<int>(sameTeamHorsesAtStart);
                allSameTeamHorses.Add(horseIndex);
                allSameTeamHorses.Sort();
                
                int firstHorse = allSameTeamHorses[0];
                
                // 첫 번째 말에 x2 UI가 있으면 업힌 상태 (이미 업힌 말들)
                if (horseManager != null && horseManager.HasHorseCountUI(firstHorse))
                {
                    // 업힌 말들과 함께 이동
                    horsesToMoveTogether.AddRange(sameTeamHorsesAtStart);
                }
            }
        }
        
        // 대기공간(-1)에서 시작하는 경우, A1(0)으로 시작
        if (playerPositions[horseIndex] == -1)
        {
            playerPositions[horseIndex] = 0; // A1에서 시작
        }
        
        for (int i = 0; i < steps; i++)
        {
            // 다음 발판으로 이동
            playerPositions[horseIndex] = (playerPositions[horseIndex] + 1) % boardPositions.Length;
            
            // 함께 이동할 말들(업힌 말들)도 같은 발판으로 이동
            foreach (int otherHorseIndex in horsesToMoveTogether)
            {
                playerPositions[otherHorseIndex] = (playerPositions[otherHorseIndex] + 1) % boardPositions.Length;
            }
            
            // 마지막 발판(최종 목적지)에서만 적의 말 잡기 및 새로 업힘 처리
            bool isLastStep = (i == steps - 1);
            if (isLastStep)
            {
                int currentPos = playerPositions[horseIndex];
                
                // 도착한 발판에 적의 말이 있으면 잡기 (같은 팀 말 처리 전에)
                List<int> enemyHorsesToCapture = new List<int>();
                for (int j = 0; j < playerPositions.Length; j++)
                {
                    if (j != horseIndex && !horsesToMoveTogether.Contains(j) && playerPositions[j] == currentPos)
                    {
                        bool jIsBarbarian = j < 4;
                        // 적의 말이면 잡기 목록에 추가
                        if (jIsBarbarian != isBarbarian)
                        {
                            enemyHorsesToCapture.Add(j);
                        }
                    }
                }
                
                // 적의 말을 잡았으면 시작 위치로 보내기
                if (enemyHorsesToCapture.Count > 0)
                {
                    foreach (int enemyHorseIndex in enemyHorsesToCapture)
                    {
                        // 해당 적의 말과 같은 위치에 있는 같은 팀 말들도 모두 찾기
                        int enemyPos = playerPositions[enemyHorseIndex];
                        List<int> enemyTeamHorses = new List<int>();
                        bool enemyIsBarbarian = enemyHorseIndex < 4;
                        
                        for (int k = 0; k < playerPositions.Length; k++)
                        {
                            if (playerPositions[k] == enemyPos)
                            {
                                bool kIsBarbarian = k < 4;
                                if (kIsBarbarian == enemyIsBarbarian)
                                {
                                    enemyTeamHorses.Add(k);
                                }
                            }
                        }
                        
                        // 적의 말(들)을 모두 시작 위치로 이동
                        foreach (int enemyTeamHorse in enemyTeamHorses)
                        {
                            Vector3 initialPosVector = horseInitialPositions[enemyTeamHorse];
                            string enemyHorseName = enemyTeamHorse < 4 ? $"바바리안{enemyTeamHorse+1}" : $"기사{enemyTeamHorse-3}";
                            // playerPositions는 대기공간(-1)으로 설정
                            playerPositions[enemyTeamHorse] = -1;
                            if (players[enemyTeamHorse] != null)
                            {
                                // NavMeshAgent 비활성화 후 위치 설정 (y좌표 증가 방지 및 위치 고정)
                                UnityEngine.AI.NavMeshAgent agent = players[enemyTeamHorse].GetComponent<UnityEngine.AI.NavMeshAgent>();
                                bool wasEnabled = agent != null && agent.enabled;
                                if (agent != null) agent.enabled = false;
                                
                                // 실제 transform.position을 대기공간 좌표로 설정
                                players[enemyTeamHorse].transform.position = initialPosVector;
                                players[enemyTeamHorse].gameObject.SetActive(true);
                                
                                // 위치 설정 후 다시 활성화하고 Warp로 위치 고정
                                if (agent != null && wasEnabled)
                                {
                                    agent.enabled = true;
                                    agent.Warp(initialPosVector); // NavMesh 위로 강제 이동
                                }
                            }
                        }
                        
                        // 잡힌 말들만 UI 업데이트 (기존 대기공간 말들은 건드리지 않음)
                        if (horseManager != null)
                        {
                            foreach (int enemyTeamHorse in enemyTeamHorses)
                            {
                                horseManager.UpdateHorseUI(enemyTeamHorse, -1, positionNames);
                            }
                        }
                    }
                }
                
                // 도착한 발판에 같은 팀 말이 있으면 함께 이동 목록에 추가 (새로 업힘)
                for (int j = 0; j < playerPositions.Length; j++)
                {
                    if (j != horseIndex && !horsesToMoveTogether.Contains(j) && playerPositions[j] == currentPos)
                    {
                        bool jIsBarbarian = j < 4;
                        // 같은 팀이면 함께 이동 목록에 추가
                        if (jIsBarbarian == isBarbarian)
                        {
                            horsesToMoveTogether.Add(j);
                        }
                    }
                }
            }
            
            // playerPositions가 -1(대기공간)이거나 유효하지 않으면 건너뛰기
            if (playerPositions[horseIndex] < 0 || playerPositions[horseIndex] >= boardPositions.Length)
            {
                Debug.LogWarning($"MoveHorseInternal: 말 {horseIndex}의 위치 인덱스가 유효하지 않습니다: {playerPositions[horseIndex]}");
                yield break;
            }
            
            Vector3 originalPosition = boardPositions[playerPositions[horseIndex]].position;
            string positionName = positionNames[playerPositions[horseIndex]];
            string horseName = horseIndex < 4 ? $"바바리안{horseIndex+1}" : $"기사{horseIndex-3}";
            
            // 같은 위치의 말들을 고려한 위치 계산 (기사 왼쪽, 바바리안 오른쪽)
            Vector3 adjustedPosition = horseManager != null 
                ? horseManager.CalculateHorsePosition(horseIndex, originalPosition)
                : originalPosition;
            // NavMesh 위에 있는 유효한 위치 찾기
            Vector3 targetPosition = GetValidNavMeshPosition(adjustedPosition);
            
            if (players[horseIndex] != null)
            {
                // NavMeshAgent가 활성화되어 있는지 확인
                if (!players[horseIndex].gameObject.activeInHierarchy)
                {
                    Debug.LogWarning($"말 {horseIndex}이 비활성화되어 있습니다!");
                    yield break;
                }
                
                // PlayerController 초기화 확인
                if (!players[horseIndex].IsInitialized())
                {
                    Debug.LogWarning($"말 {horseIndex}이 초기화되지 않았습니다. 초기화 시도...");
                    players[horseIndex].InitializeAgent();
                    yield return new WaitForSeconds(0.1f);
                }
                
                players[horseIndex].MoveToPosition(targetPosition);
                
                // 이동 완료까지 대기
                if (movementManager != null)
                {
                    yield return StartCoroutine(movementManager.WaitForMovement(players[horseIndex]));
                }
                else
                {
                    yield return StartCoroutine(WaitForMovementInternal(players[horseIndex]));
                }
                
                // 발판에 도착했는지 확인
                if (players[horseIndex] != null && players[horseIndex].transform != null)
                {
                    Vector3 beforeCheck = players[horseIndex].transform.position;
                    float distance = Vector3.Distance(players[horseIndex].transform.position, targetPosition);
                    if (distance > 0.5f)
                    {
                        Debug.LogWarning($"{horseName} (인덱스 {horseIndex})이 목표 발판에 제대로 도착하지 못했습니다. 거리: {distance}");
                        Debug.LogWarning($"[MoveHorseInternal - 강제 위치 이동 전] {horseName}: y좌표 {beforeCheck.y}, targetPosition y={targetPosition.y}");
                        // 강제로 위치 이동
                        players[horseIndex].transform.position = targetPosition;
                        Debug.LogWarning($"[MoveHorseInternal - 강제 위치 이동 후] {horseName}: y좌표 {players[horseIndex].transform.position.y}");
                    }
                    
                    // 도착 후 같은 위치의 모든 말들 위치 재계산 및 UI 업데이트 (항상 호출)
                    if (horseManager != null)
                    {
                        horseManager.RefreshHorsesAtPosition(playerPositions[horseIndex], positionNames);
                    }
                    
                    // 황금 발판인지 확인
                    if (platformManager != null && playerPositions[horseIndex] == platformManager.GoldenPlatformIndex)
                    {
                        hasExtraThrow = true;
                        platformManager.RestorePlatformColor(platformManager.GoldenPlatformIndex);
                        yield return new WaitForSeconds(0.5f); // 효과 확인 시간
                        platformManager.SelectRandomGoldenPlatform();
                    }
                }
            }
            else
            {
                Debug.LogError($"말 {horseIndex}이 연결되지 않았습니다!");
            }
            
            // 발판 간 이동 간격
            yield return new WaitForSeconds(0.1f);
        }
        
        isPlayerMoving = false;
    }
    
    // Internal 메서드로 변경 (movementManager에서 호출)
    public IEnumerator WaitForMovementInternal(PlayerController horse)
    {
        if (horse == null) yield break;
        
        float timeout = 3f;
        float elapsed = 0f;
        
        while (elapsed < timeout)
        {
            if (horse.HasReachedDestination()) break;
            
            elapsed += Time.deltaTime;
            yield return null;
        }
        
        if (elapsed >= timeout)
        {
            // 타임아웃 발생 (로그 제거)
        }
    }
    
    void InitializePlatformRenderers()
    {
        // platformManager로 위임
        if (platformManager != null)
        {
            platformManager.InitializePlatformRenderers();
        }
    }
    
    void SelectRandomGoldenPlatform()
    {
        // platformManager로 위임
        if (platformManager != null)
        {
            platformManager.SelectRandomGoldenPlatform();
        }
    }
    
    void MakePlatformGolden(int index)
    {
        // platformManager로 위임
        if (platformManager != null)
        {
            platformManager.MakePlatformGolden(index);
        }
    }
    
    void RestorePlatformColor(int index)
    {
        // platformManager로 위임
        if (platformManager != null)
        {
            platformManager.RestorePlatformColor(index);
        }
    }
    
    Vector3 CalculateHorsePosition(int horseIndex, Vector3 basePosition)
    {
        // horseManager로 위임
        if (horseManager != null)
        {
            return horseManager.CalculateHorsePosition(horseIndex, basePosition);
        }
        return basePosition;
    }
    
    void UpdateHorseCountUI(int horseIndex, int count)
    {
        // horseManager로 위임
        if (horseManager != null)
        {
            horseManager.UpdateHorseCountUI(horseIndex, count);
        }
    }
    
    // 같은 위치의 모든 말들 위치 재계산 및 UI 업데이트
    void RefreshHorsesAtPosition(int positionIndex)
    {
        // horseManager로 위임
        if (horseManager != null)
        {
            horseManager.RefreshHorsesAtPosition(positionIndex, positionNames);
        }
    }
    
    // Billboard 컴포넌트 (카메라를 향함)
    [System.Serializable]
    public class Billboard : MonoBehaviour
    {
        [System.NonSerialized]
        public Camera targetCamera;
        
        void LateUpdate()
        {
            if (targetCamera == null)
            {
                targetCamera = Camera.main;
            }
            
            if (targetCamera != null)
            {
                transform.LookAt(transform.position + targetCamera.transform.rotation * Vector3.forward,
                                targetCamera.transform.rotation * Vector3.up);
            }
        }
    }
    
    string OutcomeToKorean(YutOutcome outcome)
    {
        return YutGameUtils.OutcomeToKorean(outcome);
    }
    
    // NavMesh 위에 있는 유효한 위치 찾기
    Vector3 GetValidNavMeshPosition(Vector3 originalPosition)
    {
        return YutGameUtils.GetValidNavMeshPosition(originalPosition);
    }
    
    void UpdateUI()
    {
        if (positionText != null)
        {
            string positionInfo = "바바리안 말들:\n";
            
            // 바바리안 말들 (0~3)
            for (int i = 0; i < 4 && i < playerPositions.Length; i++)
            {
                int pos = playerPositions[i];
                if (pos == -1)
                {
                    positionInfo += $"바바리안{i+1}: 대기공간\n";
                }
                else if (pos >= 0 && pos < positionNames.Length)
                {
                    positionInfo += $"바바리안{i+1}: {positionNames[pos]}\n";
                }
                else
                {
                    positionInfo += $"바바리안{i+1}: 위치 오류 (인덱스: {pos})\n";
                }
            }
            
            positionInfo += "\n기사 말들:\n";
            
            // 기사 말들 (4~7)
            for (int i = 4; i < 8 && i < playerPositions.Length; i++)
            {
                int pos = playerPositions[i];
                if (pos == -1)
                {
                    positionInfo += $"기사{i-3}: 대기공간\n";
                }
                else if (pos >= 0 && pos < positionNames.Length)
                {
                    positionInfo += $"기사{i-3}: {positionNames[pos]}\n";
                }
                else
                {
                    positionInfo += $"기사{i-3}: 위치 오류 (인덱스: {pos})\n";
                }
            }
            
            positionText.text = positionInfo;
        }
        
        if (resultText != null)
        {
            int nextPlayerIndex = GetCurrentPlayerIndex();
            string nextPlayerName = playerNames[nextPlayerIndex];
            string turnInfo = $"다음 차례: {nextPlayerName} 팀";
            if (canThrowAgain)
            {
                turnInfo += " (한 번 더 던지세요!)";
            }
            resultText.text = turnInfo;
        }
    }

    // 빽도 판정 메서드
    bool IsBackDo(YutOutcome outcome)
    {
        if (outcome != YutOutcome.Do) return false;
        
        if (yutThrowController != null)
        {
            return yutThrowController.IsBackDo();
        }
        
        return false;
    }

    // 뒤로 이동하는 메서드
    // Internal 메서드로 변경 (movementManager에서 호출)
    public IEnumerator MoveHorseBackwardInternal(int horseIndex, int steps)
    {
        // Null 체크
        if (players == null || boardPositions == null || positionNames == null || playerPositions == null)
        {
            Debug.LogError("MoveHorseBackward: 필수 배열이 null입니다!");
            yield break;
        }
        
        // 인덱스 범위 확인
        if (horseIndex < 0 || horseIndex >= players.Length)
        {
            Debug.LogError($"잘못된 말 인덱스: {horseIndex}, players.Length: {players.Length}");
            yield break;
        }
        
        if (horseIndex >= playerPositions.Length)
        {
            Debug.LogError($"잘못된 말 인덱스: {horseIndex}, playerPositions.Length: {playerPositions.Length}");
            yield break;
        }
        
        // 시작 위치에 있으면 뒤로 갈 수 없음
        if (playerPositions[horseIndex] <= 0)
        {
            yield break;
        }
        
        isPlayerMoving = true;
        
        // 이동할 말 목록 (업힌 말들)
        // 시작 위치에 같은 팀 말이 있고, 이미 업힌 상태(x2 UI가 있음)인지 확인
        List<int> horsesToMoveTogether = new List<int>();
        int startPosition = playerPositions[horseIndex];
        bool isBarbarian = horseIndex < 4;
        
        // 대기공간(-1)에서 시작하는 경우, 대기공간의 다른 말들을 업지 않음
        if (startPosition != -1)
        {
            // 시작 위치의 같은 팀 말들 찾기 (대기공간 제외)
            List<int> sameTeamHorsesAtStart = new List<int>();
            for (int j = 0; j < playerPositions.Length; j++)
            {
                if (j != horseIndex && playerPositions[j] == startPosition && playerPositions[j] != -1)
                {
                    bool jIsBarbarian = j < 4;
                    if (jIsBarbarian == isBarbarian)
                    {
                        sameTeamHorsesAtStart.Add(j);
                    }
                }
            }
            
            // 같은 위치에 같은 팀 말이 2개 이상 있으면 업힌 상태
            // 첫 번째 말(인덱스가 작은 말)에 x2 UI가 있을 수 있음
            if (sameTeamHorsesAtStart.Count >= 1)
            {
                // 같은 위치의 같은 팀 말들 중 첫 번째 말 찾기
                List<int> allSameTeamHorses = new List<int>(sameTeamHorsesAtStart);
                allSameTeamHorses.Add(horseIndex);
                allSameTeamHorses.Sort();
                
                int firstHorse = allSameTeamHorses[0];
                
                // 첫 번째 말에 x2 UI가 있으면 업힌 상태 (이미 업힌 말들)
                if (horseManager != null && horseManager.HasHorseCountUI(firstHorse))
                {
                    // 업힌 말들과 함께 이동
                    horsesToMoveTogether.AddRange(sameTeamHorsesAtStart);
                }
            }
        }
        
        for (int i = 0; i < steps; i++)
        {
            // 이전 발판으로 이동 (뒤로)
            playerPositions[horseIndex] = Mathf.Max(0, playerPositions[horseIndex] - 1);
            
            // 함께 이동할 말들(업힌 말들)도 같은 발판으로 이동
            foreach (int otherHorseIndex in horsesToMoveTogether)
            {
                playerPositions[otherHorseIndex] = Mathf.Max(0, playerPositions[otherHorseIndex] - 1);
            }
            
            // 마지막 발판(최종 목적지)에서만 적의 말 잡기 및 새로 업힘 처리
            bool isLastStep = (i == steps - 1);
            if (isLastStep)
            {
                int currentPos = playerPositions[horseIndex];
                
                // 도착한 발판에 적의 말이 있으면 잡기 (같은 팀 말 처리 전에)
                List<int> enemyHorsesToCapture = new List<int>();
                for (int j = 0; j < playerPositions.Length; j++)
                {
                    if (j != horseIndex && !horsesToMoveTogether.Contains(j) && playerPositions[j] == currentPos)
                    {
                        bool jIsBarbarian = j < 4;
                        // 적의 말이면 잡기 목록에 추가
                        if (jIsBarbarian != isBarbarian)
                        {
                            enemyHorsesToCapture.Add(j);
                        }
                    }
                }
                
                // 적의 말을 잡았으면 시작 위치로 보내기
                if (enemyHorsesToCapture.Count > 0)
                {
                    foreach (int enemyHorseIndex in enemyHorsesToCapture)
                    {
                        // 해당 적의 말과 같은 위치에 있는 같은 팀 말들도 모두 찾기
                        int enemyPos = playerPositions[enemyHorseIndex];
                        List<int> enemyTeamHorses = new List<int>();
                        bool enemyIsBarbarian = enemyHorseIndex < 4;
                        
                        for (int k = 0; k < playerPositions.Length; k++)
                        {
                            if (playerPositions[k] == enemyPos)
                            {
                                bool kIsBarbarian = k < 4;
                                if (kIsBarbarian == enemyIsBarbarian)
                                {
                                    enemyTeamHorses.Add(k);
                                }
                            }
                        }
                        
                        // 적의 말(들)을 모두 시작 위치로 이동
                        foreach (int enemyTeamHorse in enemyTeamHorses)
                        {
                            Vector3 initialPosVector = horseInitialPositions[enemyTeamHorse];
                            string enemyHorseName = enemyTeamHorse < 4 ? $"바바리안{enemyTeamHorse+1}" : $"기사{enemyTeamHorse-3}";
                            // playerPositions는 대기공간(-1)으로 설정
                            playerPositions[enemyTeamHorse] = -1;
                            if (players[enemyTeamHorse] != null)
                            {
                                // NavMeshAgent 비활성화 후 위치 설정 (y좌표 증가 방지 및 위치 고정)
                                UnityEngine.AI.NavMeshAgent agent = players[enemyTeamHorse].GetComponent<UnityEngine.AI.NavMeshAgent>();
                                bool wasEnabled = agent != null && agent.enabled;
                                if (agent != null) agent.enabled = false;
                                
                                // 실제 transform.position을 대기공간 좌표로 설정
                                players[enemyTeamHorse].transform.position = initialPosVector;
                                players[enemyTeamHorse].gameObject.SetActive(true);
                                
                                // 위치 설정 후 다시 활성화하고 Warp로 위치 고정
                                if (agent != null && wasEnabled)
                                {
                                    agent.enabled = true;
                                    agent.Warp(initialPosVector); // NavMesh 위로 강제 이동
                                }
                            }
                        }
                        
                        // 잡힌 말들만 UI 업데이트 (기존 대기공간 말들은 건드리지 않음)
                        if (horseManager != null)
                        {
                            foreach (int enemyTeamHorse in enemyTeamHorses)
                            {
                                horseManager.UpdateHorseUI(enemyTeamHorse, -1, positionNames);
                            }
                        }
                    }
                }
                
                // 도착한 발판에 같은 팀 말이 있으면 함께 이동 목록에 추가 (새로 업힘)
                for (int j = 0; j < playerPositions.Length; j++)
                {
                    if (j != horseIndex && !horsesToMoveTogether.Contains(j) && playerPositions[j] == currentPos)
                    {
                        bool jIsBarbarian = j < 4;
                        // 같은 팀이면 함께 이동 목록에 추가
                        if (jIsBarbarian == isBarbarian)
                        {
                            horsesToMoveTogether.Add(j);
                        }
                    }
                }
            }
            
            // 배열 범위 확인 (대기공간 -1 포함)
            if (playerPositions[horseIndex] < -1 || playerPositions[horseIndex] >= boardPositions.Length || playerPositions[horseIndex] >= positionNames.Length)
            {
                Debug.LogError($"발판 인덱스 범위 오류: {playerPositions[horseIndex]}");
                yield break;
            }
            
            // 대기공간(-1)이면 건너뛰기
            if (playerPositions[horseIndex] == -1)
            {
                Debug.LogWarning($"MoveHorseBackwardInternal: 말 {horseIndex}이 대기공간에 있어 뒤로 이동할 수 없습니다.");
                yield break;
            }
            
            if (boardPositions[playerPositions[horseIndex]] == null)
            {
                Debug.LogError($"발판 {playerPositions[horseIndex]}가 null입니다!");
                yield break;
            }
            
            Vector3 originalPosition = boardPositions[playerPositions[horseIndex]].position;
            
            // 같은 위치의 말들을 고려한 위치 계산 (기사 왼쪽, 바바리안 오른쪽)
            Vector3 adjustedPosition = horseManager != null 
                ? horseManager.CalculateHorsePosition(horseIndex, originalPosition)
                : originalPosition;
            
            // NavMesh 위에 있는 유효한 위치 찾기
            Vector3 targetPosition = GetValidNavMeshPosition(adjustedPosition);
            
            if (players[horseIndex] != null)
            {
                // NavMeshAgent가 활성화되어 있는지 확인
                if (!players[horseIndex].gameObject.activeInHierarchy)
                {
                    Debug.LogWarning($"말 {horseIndex}이 비활성화되어 있습니다!");
                    yield break;
                }
                
                // PlayerController 초기화 확인
                if (!players[horseIndex].IsInitialized())
                {
                    Debug.LogWarning($"말 {horseIndex}이 초기화되지 않았습니다. 초기화 시도...");
                    players[horseIndex].InitializeAgent();
                    yield return new WaitForSeconds(0.1f);
                }
                
                players[horseIndex].MoveToPosition(targetPosition);
                
                // 이동 완료까지 대기
                if (movementManager != null)
                {
                    yield return StartCoroutine(movementManager.WaitForMovement(players[horseIndex]));
                }
                else
                {
                    yield return StartCoroutine(WaitForMovementInternal(players[horseIndex]));
                }
                
                // 발판에 도착했는지 확인
                if (players[horseIndex] != null && players[horseIndex].transform != null)
                {
                    float distance = Vector3.Distance(players[horseIndex].transform.position, targetPosition);
                    if (distance > 0.5f)
                    {
                        Debug.LogWarning($"말 {horseIndex}이 목표 발판에 제대로 도착하지 못했습니다. 거리: {distance}");
                        // 강제로 위치 이동
                        players[horseIndex].transform.position = targetPosition;
                    }
                    
                    // 도착 후 같은 위치의 모든 말들 위치 재계산 및 UI 업데이트 (항상 호출)
                    if (horseManager != null && playerPositions[horseIndex] >= -1 && playerPositions[horseIndex] < boardPositions.Length)
                    {
                        horseManager.RefreshHorsesAtPosition(playerPositions[horseIndex], positionNames);
                    }
                }
            }
            else
            {
                Debug.LogError($"말 {horseIndex}이 연결되지 않았습니다!");
            }
            
            // 발판 간 이동 간격
            yield return new WaitForSeconds(0.1f);
        }
        
        isPlayerMoving = false;
    }
    
    
    // 현재 플레이어의 모든 말 가져오기
    List<int> GetAvailableHorsesForCurrentPlayer()
    {
        List<int> availableHorses = new List<int>();
        int playerIndex = GetCurrentPlayerIndex(); // 0: 바바리안, 1: 기사
        
        // 바바리안이면 0~3, 기사면 4~7
        int startIndex = playerIndex * 4;
        int endIndex = startIndex + 4;
        
        for (int i = startIndex; i < endIndex && i < players.Length; i++)
        {
            if (players[i] != null)
            {
                availableHorses.Add(i);
            }
        }
        
        return availableHorses;
    }
    
    // 선택 가능한 말 표시
    void ShowSelectableHorses(List<int> horseIndices)
    {
        if (horseManager != null)
        {
            horseManager.ShowSelectableHorses(horseIndices);
            selectableHorseIndices = horseManager.GetSelectableHorseIndices();
        }
        else
        {
            HideSelectableHorses();
            selectableHorseIndices = new List<int>(horseIndices);
        }
    }
    
    // 선택 가능한 말 표시 제거
    void HideSelectableHorses()
    {
        if (horseManager != null)
        {
            horseManager.HideSelectableHorses();
        }
        selectableHorseIndices.Clear();
    }
    
    
    // 말 이름 가져오기
    string GetHorseName(int horseIndex)
    {
        return YutGameUtils.GetHorseName(horseIndex);
    }
    
    // 이동 가능한 발판 계산 (일직선 경로만)
    List<int> CalculateAvailablePositions(int currentPosition, int moveSteps)
    {
        return YutGameUtils.CalculateAvailablePositions(currentPosition, moveSteps, boardPositions.Length);
    }
    
    // 선택 가능한 발판 표시
    void ShowSelectablePlatforms(List<int> platformIndices)
    {
        if (platformManager != null)
        {
            platformManager.ShowSelectablePlatforms(platformIndices);
            // selectablePlatformIndices는 platformManager에서 관리하지만, 호환성을 위해 유지
            selectablePlatformIndices = new List<int>(platformIndices);
        }
        else
        {
            // 플랫폼 매니저가 없으면 기존 방식 사용
            HideSelectablePlatforms();
            selectablePlatformIndices = new List<int>(platformIndices);
        }
    }
    
    // 선택 가능한 발판 표시 제거
    void HideSelectablePlatforms()
    {
        if (platformManager != null)
        {
            platformManager.HideSelectablePlatforms();
        }
        selectablePlatformIndices.Clear();
    }
    
    
    // 선택한 발판으로 이동
    // Internal 메서드로 변경 (movementManager에서 호출)
    public IEnumerator MoveToSelectedPlatformInternal(int horseIndex, int targetPlatformIndex, YutOutcome usedMovement = YutOutcome.Nak)
    {
        isPlayerMoving = true;
        
        // 이동 전에 말이 숨겨져 있으면 일단 보이게 함
        if (players[horseIndex] != null && !players[horseIndex].gameObject.activeSelf)
        {
            players[horseIndex].gameObject.SetActive(true);
        }
        
        // 이동할 말 목록 (업힌 말들)
        // 시작 위치에 같은 팀 말이 있고, 이미 업힌 상태(x2 UI가 있음)인지 확인
        List<int> horsesToMoveTogether = new List<int>();
        int startPosition = playerPositions[horseIndex];
        bool isBarbarian = horseIndex < 4;
        
        // 대기공간(-1)에서 시작하는 경우, 대기공간의 다른 말들을 업지 않음
        if (startPosition != -1)
        {
            // 시작 위치의 같은 팀 말들 찾기 (대기공간 제외)
            List<int> sameTeamHorsesAtStart = new List<int>();
            for (int j = 0; j < playerPositions.Length; j++)
            {
                if (j != horseIndex && playerPositions[j] == startPosition && playerPositions[j] != -1)
                {
                    bool jIsBarbarian = j < 4;
                    if (jIsBarbarian == isBarbarian)
                    {
                        sameTeamHorsesAtStart.Add(j);
                    }
                }
            }
            
            // 같은 위치에 같은 팀 말이 2개 이상 있으면 업힌 상태
            // 첫 번째 말(인덱스가 작은 말)에 x2 UI가 있을 수 있음
            if (sameTeamHorsesAtStart.Count >= 1)
            {
                // 같은 위치의 같은 팀 말들 중 첫 번째 말 찾기
                List<int> allSameTeamHorses = new List<int>(sameTeamHorsesAtStart);
                allSameTeamHorses.Add(horseIndex);
                allSameTeamHorses.Sort();
                
                int firstHorse = allSameTeamHorses[0];
                
                // 첫 번째 말에 x2 UI가 있으면 업힌 상태 (이미 업힌 말들)
                if (horseManager != null && horseManager.HasHorseCountUI(firstHorse))
                {
                    // 업힌 말들과 함께 이동
                    horsesToMoveTogether.AddRange(sameTeamHorsesAtStart);
                }
            }
        }
        
        // 현재 위치에서 목표 위치까지 이동
        int currentPosition = playerPositions[horseIndex];

        // 대기공간(-1)에서 시작하는 경우, A1(0)으로 시작
        // 실제 이동이 시작될 때만 A1로 변경
        if (currentPosition == -1)
        {
            currentPosition = 0; // A1에서 시작
            playerPositions[horseIndex] = 0;
        }
        
        int stepsToMove = CalculateStepsBetween(currentPosition, targetPlatformIndex);
        
        // 발판별로 이동
        for (int i = 0; i < stepsToMove; i++)
        {
            playerPositions[horseIndex] = (playerPositions[horseIndex] + 1) % boardPositions.Length;
            
            // 함께 이동할 말들(업힌 말들)도 같은 발판으로 이동
            foreach (int otherHorseIndex in horsesToMoveTogether)
            {
                playerPositions[otherHorseIndex] = (playerPositions[otherHorseIndex] + 1) % boardPositions.Length;
            }
            
            // 마지막 발판(최종 목적지)에서만 적의 말 잡기 및 새로 업힘 처리
            bool isLastStep = (i == stepsToMove - 1);
            if (isLastStep)
            {
                int currentPos = playerPositions[horseIndex];
                
                // 도착한 발판에 적의 말이 있으면 잡기 (같은 팀 말 처리 전에)
                List<int> enemyHorsesToCapture = new List<int>();
                for (int j = 0; j < playerPositions.Length; j++)
                {
                    if (j != horseIndex && !horsesToMoveTogether.Contains(j) && playerPositions[j] == currentPos)
                    {
                        bool jIsBarbarian = j < 4;
                        // 적의 말이면 잡기 목록에 추가
                        if (jIsBarbarian != isBarbarian)
                        {
                            enemyHorsesToCapture.Add(j);
                        }
                    }
                }
                
                // 적의 말을 잡았으면 시작 위치로 보내기
                if (enemyHorsesToCapture.Count > 0)
                {
                    foreach (int enemyHorseIndex in enemyHorsesToCapture)
                    {
                        // 해당 적의 말과 같은 위치에 있는 같은 팀 말들도 모두 찾기
                        int enemyPos = playerPositions[enemyHorseIndex];
                        List<int> enemyTeamHorses = new List<int>();
                        bool enemyIsBarbarian = enemyHorseIndex < 4;
                        
                        for (int k = 0; k < playerPositions.Length; k++)
                        {
                            if (playerPositions[k] == enemyPos)
                            {
                                bool kIsBarbarian = k < 4;
                                if (kIsBarbarian == enemyIsBarbarian)
                                {
                                    enemyTeamHorses.Add(k);
                                }
                            }
                        }
                        
                        // 적의 말(들)을 모두 시작 위치로 이동
                        foreach (int enemyTeamHorse in enemyTeamHorses)
                        {
                            Vector3 initialPosVector = horseInitialPositions[enemyTeamHorse];
                            string enemyHorseName = enemyTeamHorse < 4 ? $"바바리안{enemyTeamHorse+1}" : $"기사{enemyTeamHorse-3}";
                            // playerPositions는 대기공간(-1)으로 설정
                            playerPositions[enemyTeamHorse] = -1;
                            if (players[enemyTeamHorse] != null)
                            {
                                // NavMeshAgent 비활성화 후 위치 설정 (y좌표 증가 방지 및 위치 고정)
                                UnityEngine.AI.NavMeshAgent agent = players[enemyTeamHorse].GetComponent<UnityEngine.AI.NavMeshAgent>();
                                bool wasEnabled = agent != null && agent.enabled;
                                if (agent != null) agent.enabled = false;
                                
                                // 실제 transform.position을 대기공간 좌표로 설정
                                players[enemyTeamHorse].transform.position = initialPosVector;
                                players[enemyTeamHorse].gameObject.SetActive(true);
                                
                                // 위치 설정 후 다시 활성화하고 Warp로 위치 고정
                                if (agent != null && wasEnabled)
                                {
                                    agent.enabled = true;
                                    agent.Warp(initialPosVector); // NavMesh 위로 강제 이동
                                }
                            }
                        }
                        
                        // 잡힌 말들만 UI 업데이트 (기존 대기공간 말들은 건드리지 않음)
                        if (horseManager != null)
                        {
                            foreach (int enemyTeamHorse in enemyTeamHorses)
                            {
                                horseManager.UpdateHorseUI(enemyTeamHorse, -1, positionNames);
                            }
                        }
                    }
                }
                
                // 도착한 발판에 같은 팀 말이 있으면 함께 이동 목록에 추가 (새로 업힘)
                for (int j = 0; j < playerPositions.Length; j++)
                {
                    if (j != horseIndex && !horsesToMoveTogether.Contains(j) && playerPositions[j] == currentPos)
                    {
                        bool jIsBarbarian = j < 4;
                        // 같은 팀이면 함께 이동 목록에 추가
                        if (jIsBarbarian == isBarbarian)
                        {
                            horsesToMoveTogether.Add(j);
                        }
                    }
                }
            }
            
            // playerPositions가 -1(대기공간)이거나 유효하지 않으면 건너뛰기
            if (playerPositions[horseIndex] < 0 || playerPositions[horseIndex] >= boardPositions.Length)
            {
                Debug.LogWarning($"MoveToSelectedPlatformInternal: 말 {horseIndex}의 위치 인덱스가 유효하지 않습니다: {playerPositions[horseIndex]}");
                yield break;
            }
            
            Vector3 originalPosition = boardPositions[playerPositions[horseIndex]].position;
            Vector3 adjustedPosition = horseManager != null 
                ? horseManager.CalculateHorsePosition(horseIndex, originalPosition)
                : CalculateHorsePosition(horseIndex, originalPosition);
            Vector3 targetPosition = GetValidNavMeshPosition(adjustedPosition);
            
            if (players[horseIndex] != null)
            {
                if (!players[horseIndex].gameObject.activeInHierarchy)
                {
                    yield break;
                }
                
                if (!players[horseIndex].IsInitialized())
                {
                    players[horseIndex].InitializeAgent();
                    yield return new WaitForSeconds(0.1f);
                }
                
                players[horseIndex].MoveToPosition(targetPosition);
                if (movementManager != null)
                {
                    yield return StartCoroutine(movementManager.WaitForMovement(players[horseIndex]));
                }
                else
                {
                    yield return StartCoroutine(WaitForMovementInternal(players[horseIndex]));
                }
                
                if (players[horseIndex] != null && players[horseIndex].transform != null)
                {
                    float distance = Vector3.Distance(players[horseIndex].transform.position, targetPosition);
                    if (distance > 0.5f)
                    {
                        players[horseIndex].transform.position = targetPosition;
                    }
                    
                    // 도착 후 같은 위치의 모든 말들 위치 재계산 및 UI 업데이트 (항상 호출)
                    if (horseManager != null && playerPositions[horseIndex] >= -1 && playerPositions[horseIndex] < boardPositions.Length)
                    {
                        horseManager.RefreshHorsesAtPosition(playerPositions[horseIndex], positionNames);
                    }
                    
                    if (platformManager != null && playerPositions[horseIndex] == platformManager.GoldenPlatformIndex)
                    {
                        hasExtraThrow = true;
                        platformManager.RestorePlatformColor(platformManager.GoldenPlatformIndex);
                        yield return new WaitForSeconds(0.5f);
                        platformManager.SelectRandomGoldenPlatform();
                    }
                }
            }
            
            yield return new WaitForSeconds(0.1f);
        }
        
        // 이동 완료
        isPlayerMoving = false;
        
        // 사용된 이동을 pendingMovements에서 제거 (이동 완료 후 제거)
        if (usedMovement != YutOutcome.Nak && pendingMovements.Contains(usedMovement))
        {
            pendingMovements.Remove(usedMovement);
        }
        
        // 다음 이동을 위해 상태 변수 리셋
        waitingForHorseSelection = false;
        waitingForPlatformSelection = false;
        currentHorseIndexForMove = -1;
        isBackDoTurn = false;
        
        // 대기 중인 이동이 남아있으면 턴을 종료하지 않음 (ThrowAndMoveSequence의 while 루프가 계속 진행)
        if (pendingMovements.Count > 0)
        {
            yield break; // 턴 종료하지 않고 리턴
        }
        
        // 대기 중인 이동이 없으면 턴 종료
        
        // 이동 완료 후 윷을 초기 위치로 리셋 (테스트 모드가 아닐 때만)
        if (yutThrowController != null)
        {
            yield return StartCoroutine(yutThrowController.ResetYutToStartPositionCoroutine());
            yield return new WaitForSeconds(0.3f);
        }
        
        // 다음 턴으로 이동
        canThrowAgain = false;
        int oldTurnIndex6 = currentTurnIndex;
        currentTurnIndex = (currentTurnIndex + 1) % 2; // 팀 단위 턴 변경
        turnChangedInMoveToPlatform = true; // 턴 변경 플래그 설정
        
        UpdateUI();
        
        if (throwButton != null) throwButton.interactable = true;
        EnableTestButtons();
    }
    
    // 두 위치 사이의 이동 칸 수 계산
    int CalculateStepsBetween(int from, int to)
    {
        return YutGameUtils.CalculateStepsBetween(from, to, boardPositions.Length);
    }
    
    // InputHandler를 위한 public 메서드들
    public bool IsWaitingForHorseSelection()
    {
        return waitingForHorseSelection;
    }
    
    public bool IsWaitingForPlatformSelection()
    {
        return waitingForPlatformSelection;
    }
    
    public bool IsHorseSelectable(int index)
    {
        return selectableHorseIndices.Contains(index);
    }
    
    public bool IsPlatformSelectable(int index)
    {
        return selectablePlatformIndices.Contains(index);
    }
    
    public List<int> GetSelectableHorseIndices()
    {
        return selectableHorseIndices;
    }
    
    public List<int> GetSelectablePlatformIndices()
    {
        return selectablePlatformIndices;
    }
    
    public void OnHorseSelected(int horseIndex)
    {
        if (!waitingForHorseSelection)
        {
            return;
        }
        
        if (!selectableHorseIndices.Contains(horseIndex))
        {
            Debug.LogWarning($"말 {horseIndex}는 선택 가능한 말이 아닙니다.");
            return;
        }
        
        // 말 선택 표시 제거
        HideSelectableHorses();
        
        // 선택 대기 상태 해제
        waitingForHorseSelection = false;
        
        // 빽도 턴인 경우: 말 선택 후 바로 뒤로 이동
        if (isBackDoTurn)
        {
            currentHorseIndexForMove = horseIndex;
            return; // 빽도 처리는 ThrowAndMoveSequence에서 계속 진행
        }
        
        // 선택한 말의 현재 위치
        int currentPosition = playerPositions[horseIndex];

        // 대기 중인 이동이 있으면 (윷/모 + 도/개/걸/빽도), 해당 말에서 사용 가능한 모든 이동의 발판 표시
        List<int> availablePositions = new List<int>();
        
        if (pendingMovements.Count > 0)
        {
            // 대기 중인 모든 이동에 대해 해당 말에서 이동 가능한 발판 계산
            bool hasBackDoAvailable = false;
            foreach (YutOutcome movement in pendingMovements)
            {
                // 빽도인 경우 특별 처리
                if (IsBackDo(movement))
                {
                    // 빽도는 뒤로 갈 수 있는 말만 가능 (위치가 0보다 큰 말)
                    // 대기공간(-1)의 말은 빽도 불가능
                    if (currentPosition > 0)
                    {
                        hasBackDoAvailable = true;
                    }
        }
        else
        {
                    // 일반 이동 (도/개/걸/윷/모)
                    // 대기공간(-1)에서 시작하는 경우, A1(0)에서 시작하는 것으로 계산
                    int calcPosition = currentPosition == -1 ? 0 : currentPosition;
                    int moveSteps = GetMoveSteps((int)movement);
                    List<int> positions = CalculateAvailablePositions(calcPosition, moveSteps);
                    foreach (int pos in positions)
                    {
                        if (!availablePositions.Contains(pos))
                        {
                            availablePositions.Add(pos);
                        }
                    }
                }
            }
            
            // 빽도가 있고 다른 발판이 없으면 빽도만 처리
            if (hasBackDoAvailable && availablePositions.Count == 0)
            {
                // 빽도만 가능한 경우: 바로 빽도 처리
                isBackDoTurn = true;
                currentHorseIndexForMove = horseIndex;
                return; // 빽도 처리는 ThrowAndMoveSequence의 while 루프에서 계속 진행
            }
        }
        else
        {
            // 일반 경우: 현재 moveSteps로만 이동
            availablePositions = CalculateAvailablePositions(currentPosition, currentMoveSteps);
        }
        
        // 빽도가 pendingMovements에 있는지 확인 (발판 선택 전에)
        bool hasBackDoInPending = false;
        if (pendingMovements.Count > 0 && currentPosition > 0)
        {
            foreach (YutOutcome movement in pendingMovements)
            {
                if (IsBackDo(movement))
                {
                    hasBackDoInPending = true;
                    // 빽도는 바로 전 칸 추가
                    int backPosition = currentPosition - 1;
                    if (backPosition >= 0 && !availablePositions.Contains(backPosition))
                    {
                        availablePositions.Add(backPosition);
                    }
                    break;
                }
            }
        }
        
        if (availablePositions.Count == 0)
        {
            Debug.LogWarning($"말 {horseIndex}의 이동 가능한 발판이 없습니다.");
            if (resultText != null)
            {
                resultText.text = "이동 가능한 발판이 없습니다.";
            }
            return;
        }
        
        // 발판 선택 모드로 전환 (빽도가 있으면 바로 전 칸도 표시됨)
        ShowSelectablePlatforms(availablePositions);
        currentHorseIndexForMove = horseIndex;
        waitingForPlatformSelection = true;
        
        string horseName = GetHorseName(horseIndex);
        if (resultText != null)
        {
            if (pendingMovements.Count > 0)
            {
                string movementsText = string.Join(", ", pendingMovements.Select(m => OutcomeToKorean(m)));
                resultText.text = $"{horseName} 선택됨 - 이동할 발판을 선택하세요 ({movementsText} 중 선택)";
            }
            else
            {
                resultText.text = $"{horseName} 선택됨 - 이동할 발판을 선택하세요";
            }
        }
    }
    
    public void OnPlatformSelected(int platformIndex)
    {
        if (!waitingForPlatformSelection || currentHorseIndexForMove < 0)
        {
            Debug.LogWarning($"발판 선택 조건 불만족: waitingForPlatformSelection={waitingForPlatformSelection}, currentHorseIndexForMove={currentHorseIndexForMove}");
            return;
        }
        
        if (!selectablePlatformIndices.Contains(platformIndex))
        {
            Debug.LogWarning($"발판 {platformIndex}는 선택 가능한 발판이 아닙니다. 선택 가능한 발판: {string.Join(", ", selectablePlatformIndices)}");
            return;
        }
        
        // 발판 선택 표시 제거
        HideSelectablePlatforms();
        
        // 선택 대기 상태 해제
        waitingForPlatformSelection = false;
        
        // 이동할 말 인덱스 저장
        int horseIndexToMove = currentHorseIndexForMove;
        int currentPosition = playerPositions[horseIndexToMove];
        
        // 대기 중인 이동이 있으면, 선택한 발판에 도달하는 이동을 찾아서 저장 (이동 완료 후 제거)
        YutOutcome usedMovement = YutOutcome.Nak;
        if (pendingMovements.Count > 0)
        {
            // 선택한 발판에 도달하는 이동 찾기
            foreach (YutOutcome movement in pendingMovements)
            {
                // 빽도인 경우: 바로 전 칸인지 확인
                if (IsBackDo(movement))
                {
                    int backPosition = currentPosition - 1;
                    if (platformIndex == backPosition)
                    {
                        usedMovement = movement;
                        break;
                    }
                }
                else
                {
                    // 일반 이동: moveSteps만큼 앞으로 이동
                    // 대기공간(-1)에서 시작하는 경우, A1(0)에서 시작하는 것으로 계산
                    int calcPosition = currentPosition == -1 ? 0 : currentPosition;
                    int moveSteps = GetMoveSteps((int)movement);
                    List<int> positions = CalculateAvailablePositions(calcPosition, moveSteps);
                    if (positions.Contains(platformIndex))
                    {
                        usedMovement = movement;
                        break;
                    }
                }
            }
            
            // 사용된 이동을 찾지 못한 경우, 첫 번째 이동을 사용
            if (usedMovement == YutOutcome.Nak)
            {
                usedMovement = pendingMovements[0];
                Debug.LogWarning($"선택한 발판에 정확히 매칭되는 이동을 찾지 못했습니다. 첫 번째 이동을 사용: {OutcomeToKorean(usedMovement)}");
            }
            
            // 빽도인 경우: 빽도 이동 처리 (즉시 제거)
            if (usedMovement != YutOutcome.Nak && IsBackDo(usedMovement))
            {
                pendingMovements.Remove(usedMovement);
                isBackDoTurn = true;
                // 빽도 이동은 MoveToSelectedPlatform 대신 MoveHorseBackward 사용
                if (movementManager != null)
                {
                    StartCoroutine(movementManager.MoveHorseBackward(horseIndexToMove, 1));
                }
                else
                {
                    StartCoroutine(MoveHorseBackwardInternal(horseIndexToMove, 1));
                }
                return;
            }
        }
        
        currentHorseIndexForMove = -1;
        
        // 말 이동 시작 (사용된 이동 정보를 전달하여 이동 완료 후 제거)
        if (movementManager != null)
        {
            StartCoroutine(movementManager.MoveToSelectedPlatform(horseIndexToMove, platformIndex, usedMovement));
        }
        else
        {
            StartCoroutine(MoveToSelectedPlatformInternal(horseIndexToMove, platformIndex, usedMovement));
        }
    }
    
    public bool CheckBackDoSelection(GameObject hitObject)
    {
        if (!waitingForPlatformSelection || currentHorseIndexForMove < 0 || pendingMovements.Count == 0)
        {
            return false;
        }
        
        // Terrain은 무시
        if (hitObject.name.Contains("Terrain") || hitObject.GetComponent<Terrain>() != null)
        {
            return false;
        }
        
        for (int i = 0; i < players.Length; i++)
        {
            if (players[i] == null) continue;
            GameObject playerObj = players[i].gameObject;
            
            // 클릭한 오브젝트가 현재 선택된 말인지 확인
            Transform currentCheck = hitObject.transform;
            int maxDepth = 5;
            int depth = 0;
            bool isCurrentHorse = false;
            
            while (currentCheck != null && depth < maxDepth)
            {
                if (currentCheck == playerObj.transform)
                {
                    isCurrentHorse = true;
                    break;
                }
                currentCheck = currentCheck.parent;
                depth++;
            }
            
            if (isCurrentHorse && currentHorseIndexForMove == i)
            {
                // 빽도가 pendingMovements에 있는지 확인
                bool hasBackDo = false;
                foreach (YutOutcome movement in pendingMovements)
                {
                    if (IsBackDo(movement))
                    {
                        hasBackDo = true;
                        break;
                    }
                }
                
                if (hasBackDo && playerPositions[i] > 0)
                {
                    // 빽도 선택
                    isBackDoTurn = true;
                    waitingForPlatformSelection = false;
                    HideSelectablePlatforms();
                    return true;
                }
            }
        }
        
        return false;
    }
}